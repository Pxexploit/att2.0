<?php
session_start();

if (!isset($_SESSION['usuario_email']) || $_SESSION['usuario_tipo'] !== 'vendedor') {
    echo "Você não está logado!";
    exit;
}
?>


if ($_SESSION['usuario_tipo'] == 'vendedor') {
  
    echo "Bem-vindo vendedor!";
} else {
 
    echo "Bem-vindo cliente!";
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Marketplace Taquaritinga-SP</title>
    
    <link href="css/imports_new.css" rel="stylesheet">
    <link href="css/aos.css" rel="stylesheet">
    <link rel="stylesheet" href="css/all.css">
    <script src="js/jquery.min.js"></script>
    <script src="js/aos.js"></script>
    <link href="css/MenuVendedor.css" rel="stylesheet">
    <link rel="shortcut icon" type="image/x-icon" href="images/site2.png">
</head>

<body data-aos-easing="ease" data-aos-duration="400" data-aos-delay="0">

<header id="navbar">
    <div class="container">
        <nav class="navbar navbar-expand-xl navbar-dark">
            <a class="navbar-brand" href="#"><img src="images/site2.png" alt="" style="width: 4.7rem;"></a>
            <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item active">
                        <a class="nav-link px-md-2 px-0" href="#home" onclick="change_nav(1)">Home<span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link px-md-2 px-0" href="#about" onclick="change_nav(2)">Produtos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link px-md-2 px-0" href="#pricing" onclick="change_nav(3)">Ofertas</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link px-md-2 px-0" href="#faqs" onclick="change_nav(5)">FAQ</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link px-md-2 px-0" href="#contacts" onclick="change_nav(6)">Contato</a>
                    </li>
                </ul>
                <div class="d-lg-flex d-block">
                    <a href="logout.php" class="button nav-btn d-flex justify-content-center align-items-center mt-md-0 mt-2 mb-md-0 mb-2 ml-4">Logout</a>
                    <!-- Botão visível apenas se o usuário estiver logado como vendedor -->  
                    <a href="MenuVendedor.php" class="button nav-btn d-flex justify-content-center align-items-center mt-md-0 mt-2 mb-md-0 mb-2 ml-4">Ir para Menu Vendedor</a>
                   
                </div>
            </div>
        </nav>
    </div>
</header>

<script>
    // Script para mostrar o botão quando logado
    function checkLoginStatus() {
        if (<?php echo isset($_SESSION['usuario_email']) ? 'true' : 'false'; ?>) {
            document.getElementById("menuVendedorButton").style.display = "block";
        } else {
            document.getElementById("menuVendedorButton").style.display = "none";
        }
    }
    window.onload = checkLoginStatus;
</script>

<section id="landing">
    <div class="container h-100">
        <div class="row h-100 justify-content-center align-items-center text-center">
            <div class="col-12">
                <div class="content">
                    <h1>Com <span style="color: var(--primary)">Nosso site</span><br> é mais fácil vender<span style="color: var(--primary)"> Em nossa cidade.</span></h1>
                    <p>Está procurando um produto?<br> Conheça nossa plataforma! </p>
                    <a href="produtos.php" class="button rounded-circle">Comprar pelo Site</a>
                    <a href="#0" onclick="change_nav(2)" class="button read">Saiba Mais</a>    
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
    // Função para esconder a barra de navegação quando o botão do vendedor estiver visível
    function change_nav(tab) {
        if (tab === 1) {
            $(window).scrollTop(0);
        } else if (tab === 2) {
            $(window).scrollTop($("#why-choose").offset().top - 200);
        } else if (tab === 3) {
            $(window).scrollTop($("#purchase-faq").offset().top - 100);
        } else if (tab === 4) {
            $(window).scrollTop($("#purchase-faq .faq").offset().top - 1000);
        } else if (tab === 5) {
            $(window).scrollTop($("#purchase-faq .faq").offset().top - 300);
        } else if (tab === 6) {
            $(window).scrollTop($("body").height());
        }
    }
</script>

</body>
</html>
