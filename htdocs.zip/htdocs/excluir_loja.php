<?php
session_start();

// Variáveis para mensagens
$mensagem = "";
$cadastroSucesso = false;

// Verificação de acesso apenas para vendedores
if (!isset($_SESSION['usuario_email']) || $_SESSION['usuario_tipo'] !== 'vendedor') {
    echo "Você precisa estar logado como vendedor para acessar esta página.";
    exit();
} else {

    // Conexão com o banco
    $conn = new mysqli("localhost", "root", "", "sistema_login");
    if ($conn->connect_error) {
        die("Falha na conexão: " . $conn->connect_error);
    }

    // Verifica se o vendedor tem loja
    $stmt_vend = $conn->prepare("SELECT * FROM vendedor WHERE email = ?");
    $stmt_vend->bind_param("s", $_SESSION['usuario_email']);
    $stmt_vend->execute();
    $res_vend = $stmt_vend->get_result();
    $vendedor = $res_vend->fetch_assoc();
    $id_loja = $vendedor['id_loja'];

    // Se não tem loja vinculada, redireciona
    if (is_null($id_loja)) {
        $mensagem = "Você não tem loja cadastrada.";
    } else {
        // Remover o vínculo da loja com o vendedor
        $stmt_update_vend = $conn->prepare("UPDATE vendedor SET id_loja = NULL WHERE email = ?");
        $stmt_update_vend->bind_param("s", $_SESSION['usuario_email']);

        if ($stmt_update_vend->execute()) {
            // Agora, excluir a loja
            $stmt_delete_loja = $conn->prepare("DELETE FROM loja WHERE id_loja = ?");
            $stmt_delete_loja->bind_param("i", $id_loja);

            if ($stmt_delete_loja->execute()) {
                // Sucesso
                $mensagem = "Loja excluída com sucesso!";
                $cadastroSucesso = true;
            } else {
                $mensagem = "Erro ao excluir a loja: " . $stmt_delete_loja->error;
            }
        } else {
            $mensagem = "Erro ao desvincular a loja do vendedor: " . $stmt_update_vend->error;
        }
    }

    // Fechar a conexão com o banco
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Excluir Loja</title>
    <link rel="stylesheet" href="css/cdstrovend.css">
    <style>
        /* Estilo para a mensagem de sucesso ou erro */
        #mensagemdeubom {
            color: green;
            font-weight: bold;
            margin-top: 20px;
            padding: 10px;
            background-color: #dff0d8;
            border-radius: 5px;
            text-align: center;
            display: none;
        }
        #mensagemdeubom.erro {
            background-color: #f2dede;
            color: red;
        }
    </style>
</head>
<body>

    <!-- Exibe a mensagem de status na tela de cadastro -->
    <?php if (!empty($mensagem)): ?>
        <div id="mensagemdeubom" class="<?php echo $cadastroSucesso ? '' : 'erro'; ?>">
            <?php echo $mensagem; ?>
        </div>
    <?php endif; ?>

    <!-- Formulário de cadastro da loja -->
    <div class="container">
        <h2>Cadastrar Loja</h2>

        <form action="cadastroloja.php" method="POST">
            <label for="nome_loja">Nome da Loja:</label>
            <input type="text" id="nome_loja" name="nome_loja" required>

            <label for="endereco_loja">Endereço da Loja:</label>
            <input type="text" id="endereco_loja" name="endereco_loja" required>

            <label for="cnpj_cpf_loja">CNPJ ou CPF da Loja:</label>
            <input type="text" id="cnpj_cpf_loja" name="cnpj_cpf_loja" required>

            <button type="submit" id="botaosubmit">Cadastrar Loja</button>
            <button onclick="window.location.href='MenuVendedor.php'">Voltar ao Menu</button>
        </form>
    </div>

    <script>
        // Função para exibir a mensagem
        function exibirMensagem() {
            document.getElementById("mensagemdeubom").style.display = "block";
        }

        // Exibe a mensagem de sucesso ou erro após a página carregar
        window.onload = function() {
            exibirMensagem(); // Exibe a mensagem de sucesso ou erro
        };
    </script>

</body>
</html>
