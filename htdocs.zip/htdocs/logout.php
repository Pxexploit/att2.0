<?php
session_start();
$_SESSION['deubom'] = 'LOG';

header('Location: login.php');
exit();
?>