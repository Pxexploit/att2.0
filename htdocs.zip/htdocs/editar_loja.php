<?php
session_start();

// Verificação de acesso apenas para vendedores
if (!isset($_SESSION['usuario_email']) || $_SESSION['usuario_tipo'] !== 'vendedor') {
    echo "Você precisa estar logado como vendedor para acessar esta página.";
    exit();
} else {

    // Conexão com o banco
    $conn = new mysqli("localhost", "root", "", "sistema_login");
    if ($conn->connect_error) {
        die("Falha na conexão: " . $conn->connect_error);
    }

    // Verifica se o vendedor tem loja
    $stmt_vend = $conn->prepare("SELECT * FROM vendedor WHERE email = ?");
    $stmt_vend->bind_param("s", $_SESSION['usuario_email']);
    $stmt_vend->execute();
    $res_vend = $stmt_vend->get_result();
    $vendedor = $res_vend->fetch_assoc();
    $id_loja = $vendedor['id_loja'];

    // Se não tem loja cadastrada, redireciona para a página de cadastro
    if (is_null($id_loja)) {
        header("Location: cadastroloja.php");
        exit();
    }

    // Busca os dados da loja
    $stmt_loja = $conn->prepare("SELECT * FROM loja WHERE id_loja = ?");
    $stmt_loja->bind_param("i", $id_loja);
    $stmt_loja->execute();
    $res_loja = $stmt_loja->get_result();
    $loja = $res_loja->fetch_assoc();

    // Se o formulário de edição foi enviado
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $nome_loja = $_POST['nome_loja'];
        $endereco_loja = $_POST['endereco_loja'];
        $cnpj_cpf_input = preg_replace('/[^0-9]/', '', $_POST['cnpj_cpf_loja']);

        // Verificar CNPJ ou CPF
        $cnpj = null;
        $cpf = null;
        if (strlen($cnpj_cpf_input) === 14) {
            $cnpj = $cnpj_cpf_input;
        } elseif (strlen($cnpj_cpf_input) === 11) {
            $cpf = $cnpj_cpf_input;
        }

        // Atualizar dados da loja no banco
        $stmt_update = $conn->prepare("UPDATE loja SET nome = ?, endereco = ?, cnpj = ?, cpf = ? WHERE id_loja = ?");
        $stmt_update->bind_param("ssssi", $nome_loja, $endereco_loja, $cnpj, $cpf, $id_loja);

        if ($stmt_update->execute()) {
            $mensagem = "Dados da loja atualizados com sucesso!";
            // Limpar os campos após o envio do formulário
            $nome_loja = $endereco_loja = $cnpj_cpf_input = ''; // Limpar as variáveis
        } else {
            $mensagem = "Erro ao atualizar os dados da loja: " . $stmt_update->error;
        }
    }

    // Fechar a conexão com o banco
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Loja</title>
    <link rel="stylesheet" href="css/cdstrovend.css">
</head>
<body>

    <!-- Exibe mensagem de status -->
    <?php if (!empty($mensagem)): ?>
        <div id="mensagemdeubom" style="color: green; font-weight: bold;">
            <?php echo $mensagem; ?>
        </div>
    <?php endif; ?>

    <div class="container">
        <h2>Editar Cadastro da Loja</h2>

        <form action="" method="POST">
            <label for="nome_loja">Nome da Loja:</label>
            <input type="text" id="nome_loja" name="nome_loja" value="<?php echo isset($nome_loja) ? '' : $loja['nome']; ?>" required>

            <label for="endereco_loja">Endereço da Loja:</label>
            <input type="text" id="endereco_loja" name="endereco_loja" value="<?php echo isset($endereco_loja) ? '' : $loja['endereco']; ?>" required>

            <label for="cnpj_cpf_loja">CNPJ ou CPF da Loja:</label>
            <input type="text" id="cnpj_cpf_loja" name="cnpj_cpf_loja" value="<?php echo isset($cnpj_cpf_input) ? '' : ($loja['cnpj'] ?? $loja['cpf']); ?>" required>

            <button type="submit">Salvar Alterações</button>
            <button type="button" onclick="window.location.href='MenuVendedor.php'">Voltar ao Menu</button>
        </form>
    </div>

</body>
</html>
