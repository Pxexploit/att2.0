<?php
$cadastroSucesso = false;
$verifica = false;
$mensagem = "";
session_start();

// Verificação de acesso apenas para vendedores
if (!isset($_SESSION['usuario_email']) || $_SESSION['usuario_tipo'] !== 'vendedor') {
    echo "Você precisa estar logado como vendedor para acessar esta página.";
    exit();
} else {

    // Conexão com o banco
    $conn = new mysqli("localhost", "root", "", "sistema_login");
    if ($conn->connect_error) {
        die("Falha na conexão: " . $conn->connect_error);
    }

    // Verifica se o vendedor já tem loja
    $stmt_vend = $conn->prepare("SELECT * FROM vendedor WHERE email = ?");
    $stmt_vend->bind_param("s", $_SESSION['usuario_email']);
    $stmt_vend->execute();
    $res_vend = $stmt_vend->get_result();
    $vendedor = $res_vend->fetch_assoc();
    $id_loja = $vendedor['id_loja'];

    // Se já tem loja cadastrada, exibe mensagem e os botões de editar e excluir
    if (!is_null($id_loja)) {
        $verifica = true;
        // Busca os dados da loja
        $stmt_loja = $conn->prepare("SELECT * FROM loja WHERE id_loja = ?");
        $stmt_loja->bind_param("i", $id_loja);
        $stmt_loja->execute();
        $res_loja = $stmt_loja->get_result();
        $loja = $res_loja->fetch_assoc();
        $mensagem = "Você já possui uma loja cadastrada no nosso sistema!";
    }

    // Se for envio de formulário para cadastro de loja
    if ($_SERVER["REQUEST_METHOD"] === "POST" && !$verifica) {
        $email_vendedor = $_SESSION['usuario_email'];
        $nome_loja = $_POST['nome_loja'];
        $endereco_loja = $_POST['endereco_loja'];
        $cnpj_cpf_input = preg_replace('/[^0-9]/', '', $_POST['cnpj_cpf_loja']);

        // Determinar se é CNPJ ou CPF
        $cnpj = null;
        $cpf = null;
        if (strlen($cnpj_cpf_input) === 14) {
            $cnpj = $cnpj_cpf_input;
        } elseif (strlen($cnpj_cpf_input) === 11) {
            $cpf = $cnpj_cpf_input;
        } else {
            $mensagem = "CNPJ ou CPF inválido.";
        }

        if (empty($mensagem)) {
            // Inserir loja
            $stmt_loja = $conn->prepare("INSERT INTO loja (nome, endereco, cnpj, cpf) VALUES (?, ?, ?, ?)");
            if ($stmt_loja === false) {
                die('Erro ao preparar a consulta: ' . $conn->error);
            }

            // Vincular os parâmetros
            $stmt_loja->bind_param("ssss", $nome_loja, $endereco_loja, $cnpj, $cpf);

            // Executar a consulta
            if ($stmt_loja->execute()) {
                $id_loja = $conn->insert_id;

                // Atualiza a loja do vendedor
                $stmt_vend = $conn->prepare("UPDATE vendedor SET id_loja = ? WHERE email = ?");
                $stmt_vend->bind_param("is", $id_loja, $email_vendedor);

                if ($stmt_vend->execute()) {
                    $mensagem = "Loja cadastrada com sucesso e vinculada ao vendedor!";
                    $cadastroSucesso = true;
                    $verifica = true;

                    // Buscar novamente a loja para exibição dos dados
                    $stmt_loja = $conn->prepare("SELECT * FROM loja WHERE id_loja = ?");
                    $stmt_loja->bind_param("i", $id_loja);
                    $stmt_loja->execute();
                    $res_loja = $stmt_loja->get_result();
                    $loja = $res_loja->fetch_assoc();
                } else {
                    $mensagem = "Erro ao vincular loja ao vendedor: " . $stmt_vend->error;
                }
            } else {
                $mensagem = "Erro ao cadastrar loja: " . $stmt_loja->error;
            }

            // Fechar a consulta da loja
            $stmt_loja->close();
        }
    }

    // Fechar a conexão com o banco
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar Loja</title>
    <link rel="stylesheet" href="css/cdstroloja.css">
</head>
<body>

    <!-- Exibe mensagem de status -->
    <?php if (!empty($mensagem)): ?>
        <div id="mensagemdeubom" style="font-weight: bold;">
            <?php echo $mensagem; ?>
        </div>
    <?php endif; ?>

    <!-- Exibe o formulário de cadastro se o vendedor NÃO tem loja -->
    <?php if (!$verifica): ?>
        <div class="container">
            <h2>Cadastrar Loja</h2>

            <form action="" method="POST">
                <label for="nome_loja">Nome da Loja:</label>
                <input type="text" id="nome_loja" name="nome_loja" required>

                <label for="endereco_loja">Endereço da Loja:</label>
                <input type="text" id="endereco_loja" name="endereco_loja" required>

                <label for="cnpj_cpf_loja">CNPJ ou CPF da Loja:</label>
                <input type="text" id="cnpj_cpf_loja" name="cnpj_cpf_loja" required>

                <button type="submit">Cadastrar Loja</button>
                <button type="button" onclick="window.location.href='MenuVendedor.php'">Voltar ao Menu</button>
            </form>
        </div>
    <?php endif; ?>

    <!-- Exibe os botões de Editar e Excluir Loja imediatamente após o cadastro -->
    <?php if ($verifica): ?>
        <div class="container">
            <h2>Loja Cadastrada</h2>
            <p><strong>Nome da Loja:</strong> <?php echo $loja['nome']; ?></p>
            <p><strong>Endereço:</strong> <?php echo $loja['endereco']; ?></p>
            <p><strong>CNPJ/CPF:</strong> <?php echo $loja['cnpj'] ?? $loja['cpf']; ?></p>

            <!-- Botões de editar e excluir a loja -->
            <form action="editar_loja.php" method="GET">
                <button type="submit">Editar Cadastro da Loja</button>
            </form>
            <form action="excluir_loja.php" method="POST" onsubmit="return confirm('Tem certeza que deseja excluir a loja?');">
                <button type="submit" style="background-color: red;">Excluir Loja</button>
            </form>
            <form action="MenuVendedor.php" method="GET">
                <button type="submit">Voltar ao Menu</button>
            </form>
        </div>
    <?php endif; ?>

    <?php if ($cadastroSucesso): ?>
        <script>
            document.getElementById("nome_loja").disabled = true;
            document.getElementById("endereco_loja").disabled = true;
            document.getElementById("cnpj_cpf_loja").disabled = true;
        </script>
    <?php endif; ?>

</body>
</html>
